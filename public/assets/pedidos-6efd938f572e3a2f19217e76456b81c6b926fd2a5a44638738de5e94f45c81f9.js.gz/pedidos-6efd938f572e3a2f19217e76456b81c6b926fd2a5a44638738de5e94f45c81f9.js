$(document).ready ->
  alert('entrou');

 $('#edit_qt_pedido').keyup (e)->
      alert('ok')
;
